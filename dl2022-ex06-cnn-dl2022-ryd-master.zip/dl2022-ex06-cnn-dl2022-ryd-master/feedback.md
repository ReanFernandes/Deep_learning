# Please give us feedback to help us improve the exercises. You get 1 bonus point for submitting feedback.

## Major Problems?

Assignment was considerably longer than the previous ones, with multiples tasks. the tasks were definitely helpful, but the questions could have been made more specific, especially for the convolution implementation.

## Helpful?
Very detailed implementation of equivariance and shifted dataset. It was helpful in understanding how the shifting of the dataset changes the performance of the model


## Duration (hours)?

_Please make a list where every student in your group puts in the hours they used to do the complete exercise_
_Example: [5.5, 4, 7], if one of you took 5 and a half hours, one person 4 and the other 7. The order does not matter._
_This feedback will help us analyze which exercise sheets are too time-intensive._

[8]

## Other feedback?



