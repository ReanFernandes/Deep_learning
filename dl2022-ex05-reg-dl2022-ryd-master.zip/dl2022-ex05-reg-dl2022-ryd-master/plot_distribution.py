from lib.plot import plot_distribution


def main():
    plot_distribution()


if __name__ == '__main__':
    main()
