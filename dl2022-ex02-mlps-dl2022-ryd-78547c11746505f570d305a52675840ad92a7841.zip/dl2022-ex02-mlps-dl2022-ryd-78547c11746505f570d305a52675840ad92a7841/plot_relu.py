"""Script to plot the ReLU."""

from lib.plot import plot_relu


def main():
    plot_relu()


if __name__ == '__main__':
    main()
