"""Dataset definition."""

import numpy as np


# training set
X = np.array([[0, 0],
              [0, 1],
              [1, 0],
              [1, 1]])

# true labels
y = np.array([0, 1, 1, 0])
