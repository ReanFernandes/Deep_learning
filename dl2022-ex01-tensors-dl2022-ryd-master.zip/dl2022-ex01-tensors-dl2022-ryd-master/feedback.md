# Please give us feedback to help us improve the exercises. You get 1 bonus point for submitting feedback.

## Major Problems?

Major problem was in the distributions question as it was not clear enough. There was much ambiguity in this question in terms of wordings and the order of to do parts.

## Helpful?

The assignmt was so much helpful in pointing out some important concepts in coding and gave us a refresh in linear algebra and in probability as well.

## Duration (hours)?

_Please make a list where every student in your group puts in the hours they used to do the complete exercise_
_Example: [5.5, 4, 7], if one of you took 5 and a half hours, one person 4 and the other 7. The order does not matter._
_This feedback will help us analyze which exercise sheets are too time-intensive._

[6 5 8]

## Other feedback?

We really enjoyed solving the assignment and we appreciate how much it is organized. Also the option of testing our solutions were so much helpful and a great guidence while implemnting different functions. 

