"""Show random train images"""
from lib.utils import show_random_train_images

if __name__ == '__main__':
    show_random_train_images()
