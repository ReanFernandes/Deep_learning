from lib.plot import plot_attention


if __name__ == "__main__":
    plot_attention()
