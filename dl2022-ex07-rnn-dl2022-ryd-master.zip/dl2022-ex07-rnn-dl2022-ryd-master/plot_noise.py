"""Script to plot the original/noisy signals and the model predictions"""

from lib.plot import plot_functions_with_noise


if __name__ == '__main__':
    plot_functions_with_noise()
