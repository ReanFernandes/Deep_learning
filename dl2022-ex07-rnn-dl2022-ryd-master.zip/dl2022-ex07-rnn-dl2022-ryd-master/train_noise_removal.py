from lib.experiments import train_noise_removal_model


if __name__ == '__main__':
    train_noise_removal_model()
