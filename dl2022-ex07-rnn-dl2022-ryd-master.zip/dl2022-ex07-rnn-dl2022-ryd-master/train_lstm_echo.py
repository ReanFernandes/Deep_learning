from lib.experiments import train_lstm_echo


if __name__ == '__main__':
    train_lstm_echo()
