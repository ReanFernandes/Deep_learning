# Please give us feedback to help us improve the exercises. You get 1 bonus point for submitting feedback.

## Major Problems?

By far the most difficult and lengthy exercises, but Most of the errors I encountered were due to my own lack of grasp of the material. But very big nonetheless.

## Helpful?
Being the longest exercise till now, it was also the most helpful and I can confidently say that this exercise was what made me grasp the concepts and truly made me see that exercises are absolutely important for understanding.


## Duration (hours)?

_Please make a list where every student in your group puts in the hours they used to do the complete exercise_
_Example: [5.5, 4, 7], if one of you took 5 and a half hours, one person 4 and the other 7. The order does not matter._
_This feedback will help us analyze which exercise sheets are too time-intensive._

[15]

## Other feedback?
I wasnt able to use my GPU for training, I followed all the instructions as per the exercise, but in the end it only ran on my cpu. Perhaps in the coming exercise session I will sit with one of the tutors and figure it out. - Rean


