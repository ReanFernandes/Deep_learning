from lib.experiments import run_hpo


if __name__ == '__main__':
    run_hpo()
