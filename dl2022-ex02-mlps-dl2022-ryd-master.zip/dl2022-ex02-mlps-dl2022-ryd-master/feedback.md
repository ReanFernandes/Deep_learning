# Please give us feedback to help us improve the exercises. You get 1 bonus point for submitting feedback.

## Major Problems?
- Rean - None.
- Yumna - None.

## Helpful?
- Rean -  Very very helpful. I was able to understand what I was applying and connect it to what was taught in the lecture. Awesome Exercise.
- Yumna - It made me practise what I have already understood from the lecture. Also, implementing each step in MLP made us fully digest how it works inside by coding and by maths calculations.

## Duration (hours)?

_Please make a list where every student in your group puts in the hours they used to do the complete exercise_
_Example: [5.5, 4, 7], if one of you took 5 and a half hours, one person 4 and the other 7. The order does not matter._
_This feedback will help us analyze which exercise sheets are too time-intensive._

[8, 6, 10]

## Other feedback?



