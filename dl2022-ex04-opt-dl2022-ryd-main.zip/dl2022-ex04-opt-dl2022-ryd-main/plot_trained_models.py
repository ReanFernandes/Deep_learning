from lib.plot import plot_learning_curves


def plot():
    plot_learning_curves()


if __name__ == '__main__':
    plot()
