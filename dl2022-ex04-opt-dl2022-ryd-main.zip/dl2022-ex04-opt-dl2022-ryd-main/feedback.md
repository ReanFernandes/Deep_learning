# Please give us feedback to help us improve the exercises. You get 1 bonus point for submitting feedback.

## Major Problems?

Yumna: There are some functions that didn't have enough explanation/definition in the assignment or in the function's 
signature like piecewise scheduler.  
Rean : Encountered major difficulty while solving for piecewise linear. The scheduled learning rate array was a 5 element list, but the epochs for change were only 4 i.e 1,3,5,9 which meant that we had to manually override the learning rate for the 10th epoch.Maybe there might be another way, but this was the most difficult part of the exercise. I agree with Yumna that more detailed descriptions could have  been given as the problems we faced were not really with the subject matterbut rather with how  the code was given.

## Helpful?

Yumna: It was helpful assignment that made us implement the optimization part by ourselves
Rean: Very Helpful, I learnt alot about the content for this week, which was heavier than the past as it covered multiple subtopics. All in all, 8/10 exercise




## Duration (hours)?

_Please make a list where every student in your group puts in the hours they used to do the complete exercise_
_Example: [5.5, 4, 7], if one of you took 5 and a half hours, one person 4 and the other 7. The order does not matter._
_This feedback will help us analyze which exercise sheets are too time-intensive._

[6, 12]

## Other feedback?
We suggest that final answers for pen and paper questions would be provided so the grade focus mainly would be on the steps,
so that we would be certain while solving the calculations.

