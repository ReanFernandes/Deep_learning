from lib.plot import plot_lr_schedules


def plot():
    plot_lr_schedules()


if __name__ == '__main__':
    plot()
