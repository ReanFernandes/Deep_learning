# Please give us feedback to help us improve the exercises. You get 1 bonus point for submitting feedback.

## Major Problems?

In question number 3, I didn't know that the order of operations in structure list matters for the test. I spent a lot
of time debugging this problem. As, it was clarified in the sheet that we should write the OPS in certain order.

## Helpful?

It was so helpful in the practical side as I could not digest the lecture alone without applying the theoretical part.

## Duration (hours)?

_Please make a list where every student in your group puts in the hours they used to do the complete exercise_
_Example: [5.5, 4, 7], if one of you took 5 and a half hours, one person 4 and the other 7. The order does not matter._
_This feedback will help us analyze which exercise sheets are too time-intensive._

[6]

## Other feedback?



